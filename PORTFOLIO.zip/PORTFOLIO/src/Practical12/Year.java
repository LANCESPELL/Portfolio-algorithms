package Practical12;

public enum Year {
    FIRST_YEAR, SECOND_YEAR, PLACEMENT_YEAR, FINAL_YEAR
}
