package Practical13;

public enum TokenType {
    COMPARISON,
    LOGICAL,
    NUMERIC,
    BOOLEAN
}
